# Installation
> `npm install --save @types/mdurl`

# Summary
This package contains type definitions for mdurl (https://github.com/markdown-it/mdurl#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/mdurl

Additional Details
 * Last updated: Wed, 17 Oct 2018 20:11:23 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Junyoung Choi <https://github.com/rokt33r>.
