# @firebase/auth-interop-types

## 0.1.7

### Patch Changes

- [`4af28c1a4`](https://github.com/firebase/firebase-js-sdk/commit/4af28c1a42bd25ce2353f694ca1724c6101cbce5) [#6682](https://github.com/firebase/firebase-js-sdk/pull/6682) - Upgrade TypeScript to 4.7.4.

## 0.1.6

### Patch Changes

- [`3f370215a`](https://github.com/firebase/firebase-js-sdk/commit/3f370215aa571db6b41b92a7d8a9aaad2ea0ecd0) [#4808](https://github.com/firebase/firebase-js-sdk/pull/4808) (fixes [#4789](https://github.com/firebase/firebase-js-sdk/issues/4789)) - Update peerDependencies
