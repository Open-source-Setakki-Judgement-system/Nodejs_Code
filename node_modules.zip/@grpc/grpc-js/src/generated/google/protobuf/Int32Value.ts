// Original file: null


export interface Int32Value {
  'value'?: (number);
}

export interface Int32Value__Output {
  'value': (number);
}
