// Original file: null

import type { Long } from '@grpc/proto-loader';

export interface UInt64Value {
  'value'?: (number | string | Long);
}

export interface UInt64Value__Output {
  'value': (string);
}
